# API

## Defining an API

## Communicating an API

# Design

## Defining supporting Models

## Communicating any deviations