# Azure
Azure is a cloud computing service created by Microsoft for building, testing, deploying, and managing applications and services through Microsoft-managed data centers. 
In order to host our application, we needed to either find a provider or host it ourselves. Since we did not want to manage our own resources and incur upfront charges, we opted for an online service provider. In addition, with this option we are able to easily scale up or down our resources, paying only for what we consume. 

When it comes to picking a service provider, there are many considerations, including but not limited to: Security, Compliance, Architecture, Manageability, Services Level, Support and Cost. The top contenders for hosting came down to Amazon AWS and Microsoft Azure. The primary differentiating factors that ultimately led us to Azure were: Architecture, Ease of Setup, and Cost. In this document we will evaluate the cost breakdown. 

**Cost** <br/>
In order to compare the cost of Azure App Service and AWS, we utilized their pricing calculators with the same configuration values. The pricing is as follows: 

### Azure

![Azure-App-Service.png](https://i.postimg.cc/pXRbWzJ9/Azure-App-Service.png)


### AWS

![AWSApp-Service1.png](https://i.postimg.cc/tJ76WYhF/AWSApp-Service1.png)

![AWSApp-Service2.png](https://i.postimg.cc/502QW6KD/AWSApp-Service2.png)

We can see that given the 4 core 10gb storage, Azure is almost 50% cheaper when compared to AWS. While both services offer the free tier, we used the standard tiers as this will provide a more realistic comparison for long-term usage. 

# Cosmos DB Pricing

Cosmos DB is a NoSQL Database that offers guaranteed speed and availability along with instant scalability.
The cost breakdown is based on database operations expressed as request units per second (RU/s). In addition, storage is billed as GB consumed by SSD-backed data. There are two options when it comes to pricing models: Autoscale and Manual
### Autoscale
Eliminates the need to manage capacity by automatically scaling up or down. Starting at 4000 RU/s, the autoscale pricing bills based on the maximum RU/s used each hour. This is best for unpredictable traffic. 
### Manual 
Allows you to directly manage capacity with standard throughput. Starting at a minimum of 400 RU/s you will be billed an hourly rate for the RU/s provisioned. This is best for predictable traffic.

## Price Difference
The price per 100 RU/s for manual provision is $.008/hour vs $.012/hour for autoscale. If we are to use the minimum RU/s deployable for the manual version (400 RU/s), that equates to **$23.81/month** for just the RU/s (not including storage). For the same 400 RU/s in the autoscale pricing, it will be **$35.71/month**. 

Since we know the amount of RU/s we will need it is better for us to choose the manual version. We are also not enforced to provision 4000 RU/s in this plan. With that, let us evaluate our current DB use and expected use as the application grows. 

#### Price Breakdown
Since we are using under 400 RU/s, based on our throughput data, we opted to use the Cosmos DB free tier. This means we get free 400 RU/s with shared throughput. Thus, we can have up to 25 containers that share the 400 RU/s with a total of 5 Databases. 

For example, if we have 4 containers in a database with 400 RU/s shared, Cosmos will auto allocate the resources to allow the containers to send and receive data. This is guaranteed for the lifetime of the account along with 5GB of storage. As long we don't create a database with a dedicated throughput of 400 min RU/s, our pricing is **Free**.

### Future Cost and Scaling
We anticipate this site to continue growing users along with the endpoints resulting in higher RU/s and storage requirements. Currently the resources consumed are from 5 users and the current endpoints represent 50% of total endpoints we expect by production ready application. Thus, with an estimated user base of 10,000 users and 2 times the current endpoints, we have the following DB usage breakdown. 

![DB Estimate](https://i.postimg.cc/tgHjXryz/DBEstimate.png)

Thus, the 5GB we have currently suffices. As for the updates and reads, we anticipate the following DB operation requests on average. This is based on our max existing throughput: 
Read: 250 RU/s 
Create: 20 RU/s
Update: 10 RU/s
Delete: 5 RU/s.

Using the price calculator available on the azure [website](https://cosmos.azure.com/capacitycalculator/) we can input the values above to get the actual estimate for the month. Note, we've used 5GB as the storage space. This is based on the current usage of 864KB (less than 1GB). Thus we believe 5GB is sufficient per month. It is also the standard storage that is available in the free tier. 
As you can see in the image below, the total estimated price per month is **$30.11**
[![azurepricing.png](https://i.postimg.cc/QCYHhsV3/azurepricing.png)](https://postimg.cc/2Lvz7s4c)
