Welcome to the ForkInTheCode wiki!

# Project overview
FiTR Skills is an application that aims to help job seekers find and acquire skills that are being
sought after in the workforce.  This application aims to guide job seekers through this skill 
acquisition process with the following goals.

- Lower the skill gap by helping job seekers know what skills they should acquire.
- Connect employers to job seekers that have the skills they are looking for.
- Provide educators a platform to connect their courses with individuals who are seeking those skills.
- Reduce employer bias by obfuscating or hiding job seeker's personal information.

These goals are supported by the general workflow that all job seekers aim to take on this
platform.

1. Search for needed skills in the area you wish to work.
2. Select skills you already have and add them to your profile.
3. Search for jobs in your area that require several of the skills you possess.
4. Find jobs that are interesting and view what skills you are missing.
5. Search for courses with those skills so that you can acquire them.
6. Learn from the courses and repeat from step 1.

# Terminology

| Term         | Definition
|--------------|------------
| Skill        | An ability or credential that employers seek
| Job Seeker   | A user who is primarily using the site to accuire new jobs or connect with employers
| Organization | An entity that multiple users can belong to which can own job postings or courses
| Employer     | A user belonging to an organization that has permissions to edit job postings on behalf of that organizaiton.
| Educator     | A user belonging to an organization that has permissions to edit courses on behalf of that organization.

# Getting started
There is a lot of information on this wiki, it is not meant to be read as a book, but rather
referenced as needed.  Listed here are some things that you should look at if you are
completely in the dark about the project.

1. [Other Resources](https://github.com/Lixnir/ForkInTheCode/wiki/Resource-Directory):
   This page outlines the tech stack used and things you should be familiar with. Give this
   one a quick look for now and reference it in more detail later.
2. [Development Enviornment Setup](https://github.com/Lixnir/ForkInTheCode/wiki/Development-Environment):
   The fastest way to learn is to start poking around, follow these instructions to get the
   app to run.
3. [Wiki Meta Information](https://github.com/Lixnir/ForkInTheCode/wiki/Meta-Wiki):
   As you continue to look at this wiki, you should first have an appreciation of why the wiki
   is the way it is, a brief look for now, but reference this page if you are going to make changes.
4. [Domain Definition](https://github.com/Lixnir/ForkInTheCode/wiki/Domain-Definition):
   Get a more solid understanding of what the purpose of this application is and who the
   users are.
5. [Project Structure](https://github.com/Lixnir/ForkInTheCode/wiki/Project-Structure):
   Figure out what all the files and folders mean.
6. Any page that is relevant: Requirements, process, architecture, testing, etc. will all come
   up eventually. Those pages should be referenced as needed.