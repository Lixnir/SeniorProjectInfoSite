It is very likely that at some point a team will end up with duplicate code that runs on both
the frontend and backend.  While this isn't something very important, this page lists some
ideas that could help make the most of this kind of situation.

- **Author**: Alex Wilkes <[adw4236@rit.edu](mailto:adw4236@rit.edu)>

# Common Code
There are several instances where code may end up needing to run on the frontend and the backend.
One instance that came to mind several times during initial development was input validation.
It would be very nice if we could ensure that both the frontend and backend were validating input
in the exact same way.  It is ultimately up to a future team if they think this is worth implementing
for input validation.

Either way, other instances may arise where code needs to be shared.  While it may be tempting to
just have a top level folder that both projects can import from, this does have some drawbacks,
primarily in readability, but also potentially in the usage of webpack as well.

Instead, a new Node.JS sub-project should be created (similar to client and server) and labeled
[private](https://docs.npmjs.com/cli/v7/configuring-npm/package-json#private).  That same module
can then be installed by both the frontend and backend, i.e. `npm install ../core`.

[Linking](https://docs.npmjs.com/cli/v7/commands/npm-link) may also be an option worth looking into.