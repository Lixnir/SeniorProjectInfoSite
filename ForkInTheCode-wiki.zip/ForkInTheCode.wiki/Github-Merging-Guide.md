This page provides information about Github Merging and Editing.

- Author: Rachael Daly <[rld5989@rit.edu](mailto:[rld5989@rit.edu])>

# Merging into Sprint Branch

When merging into the sprint branch it is required for there to be at least one reviewer approving the merge. If after assigning people to review the merge and @'ing them in Discord 48 hours have passed with no response the merger is free to merge as long as all tests passed.

When a reviewer notices they have to review a merge they may comment in the merge that they cannot review in the 48 hour window, and must give a timeframe for when they will complete it. If they do not give a timeframe the 48 hour clock begins from when they responded. If they did give a timeframe the merger may merge after it has passed.

# Merging into Master

At Wednesday night before the end of each sprint The Github Police will verify all merges to the sprint branch have been completed, if the merge is not in before 9pm Wednesday night **it will be disregarded and must be merged into the next sprint**. The Github Police will @everyone within the discord asking them to make sure their branches are merged in or requested to be not deleted. Then the sprint merge to master will be created, and will be merged before Thursday's meeting. Everyone must verify the merge to master before the meeting.

## Branches That Were Not Merged

Branches that were not merged into the sprint they were created in will be deleted along with the rest of the branches, Thursday after the sprint ends. In order to not have them deleted the owner must request them to be saved within the discord channel **github-preserved-branches**. Template format is as follows.

> Branch Name: [Name]<br />
> User: [Full Name]<br />
> Reason for Saving: [Reason]<br />
> Expected Merge Date: [MM/DD/YYYY]

When the branch is merged into a sprint branch and then can be deleted, the User specified in the save request must delete the request in the discord. 

# Issues

Issues should be closed on merges and for reviews/comments will follow the rules of merging.
