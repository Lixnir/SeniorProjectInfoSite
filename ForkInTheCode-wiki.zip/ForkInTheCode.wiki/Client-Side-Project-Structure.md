# 1. Source code (/src)
The "src" folder holds all the implementations for the client side of the project.

## Components
The "components" folder holds all components that are responsible for building the client interface and handling the
client logic.

### Pages
The "pages" folder holds all the components that are responsible for displaying an entire page of the web-application to 
the user. Pages usually consist of multiple sub-components to avoid code complexity and redundancy.

### Sub-components
The "sub-components" folder holds all the reusable components that implement features commonly used throughout the 
application, thus mitigate code duplication or repetition.

## Redux
The "redux" folder holds all the implementations necessary for the success of the Redux integration into the web-application.

### Actions
The "actions" folder holds all the actions of the web-application, which initiate requests for changes in the global state.

### Reducers
The "reducers" folder holds all reducers of the web-application, which dispatch the changes from the actions and modify 
the global state.

# 2. Cypress (/cypress)
The "cypress" folder holds all the testing scripts and commands necessary for executing the Cypress automated tests.

## Integration
The "integration" folder holds all the Cypress test scripts.

## Support
The "support" folder holds all the commands that replace repetitive or commonly used steps in Cypress tests.

# 3. Environment & Configuration
In order for the web-application to build and run successfully, there are certain environment variables and configuration
needed to set up.

## .env
.env file holds all the environment variables needed for the deployment of the web-application, such as client or server domain.
It has to be created locally and must not be ignored by Git.

## package.json
Package.json holds all the development dependencies, run scripts and other configurations needed for the deployment of the
web-application.

## cypress.json
Cypress.json holds all the environment variables and configuration for the execution of Cypress test scripts, 
such as client or server domain.
