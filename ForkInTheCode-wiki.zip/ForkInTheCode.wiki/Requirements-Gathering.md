# Requirements Gathering Process

The way that we have gathered requirements has evolved over the project's lifespan. What it ended up being is we would give Jeff the template linked below, and we would then turn that into documented requirements using the template under the Requirements heading in the sidebar.

[Requirements Template](https://docs.google.com/document/d/1RojQ73mBaefpwKX-BhBxnERDkleQoJ162DOZHFziMos/edit?usp=sharing)

[Folder of already filled out templates](https://drive.google.com/drive/folders/16wD_WrLX_Mm1Aj5fiyua0YfoCFfZHhpf?usp=sharing)
