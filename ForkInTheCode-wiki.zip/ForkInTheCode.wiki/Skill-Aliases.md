Skills are the core of this application and as such, there was a lot that we discussed that
is not implemented.  This page outlines the additional pieces that could be implemented.

- **Author**: Alex Wilkes <[adw4236@rit.edu](mailto:adw4236@rit.edu)>

# Skill Aliases
Part of the goal of this platform is to develop a standard skill language that organizations
can all reference.  Because of this, most skills that need to be standardized will have multiple
terms to refer to them by.  Aliases would provide a way to have multiple words refer to the same
core skill.

First, aliases would not replace the core name of the skill.  Every skill should have a primary
name that is unique.  Aliases would simply provide more search terms.

During the search, typing in the name of a skill would work the same as it currently does, suggesting
similarly named skills.  The search however would also compare the input to all aliases of all
skills as well.  Any aliases that are close matches would also have their skill returned as an
option.  In the dropdown select for those skills, the skill name would show as normal with the
alias that is closely matched in parentheses after the skill name.

In instances where a skill can be created (i.e. Employers or Educators during the creation of a
Job Posting or Course) there would also be the option to instead just add the new name as an
alias to an existing skill.  This would likely be an option in the popup dialog that allows
for the creation of a skill.

A much later thought is that there will have to be some way to merge skills as an administrator
of the system.  In this case, all the aliases and the name of one skill will be added as
aliases to another skill.