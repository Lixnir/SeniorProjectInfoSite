This project has yet to implement any sort of email verification.  This page outlines
the steps that would need to be taken in order to do so.

- **Author**: Alex Wilkes <[adw4236@rit.edu](mailto:adw4236@rit.edu)>

# Email Verification
The primary reason we did not implement the email verification was because we didn't have a reliable
way to test such a system on our azure deployment.  To do so would require using a framework that
would allow our code to automatically dispatch emails and that seemed out of scope for the project
at the time.

## Sending Emails
First, the team will need some SMTP server that they have an email on which they can use to send
emails from.  Jeff may have an official FiTR email, but if not, at least for testing, you can use
[Google's SMTP server]().

The account credentials for that email should be stored in environment variables.

Then through a npm package like [smtp-client](https://www.npmjs.com/package/smtp-client) or any
equivalent higher level framework you should be able to send emails.

If the team is opting for a lower level API like the one listed above, it is highly suggested that
they spend time designing a re-usable subsystem for formatting emails for multiple purposes since
it seems this project will rely heavily on emails at first.

## Verification Links
Once you can send emails, you need a way to be able to create links users can click on to verify
their emails (or change passwords, etc.).  Ultimately the design choice for this is up to the
team that implements this, but if you are struggling to think of how, I have some quick thoughts
listed below.

1. Add a `verified` field in the user model that defaults to false.
2. Create a new model `verification` that has a reference to the user ID and can store
   other information like expiration time.
3. Use the ID from the newly created model as a path parameter or query parameter in the
   link that is generated
4. That link should point to some API endpoint (or page that sends a request to one) with
   the provided object ID.
5. If the verification object is still valid, then mark the associated user's account as
   verified.

## Find a Framework
Everything listed above should work, but this is in the realm of something the team should likely
try to find a good framework to do for them.  Some things to keep in mind while searching for a
framework:

- More than just verification emails will need to be sent
- Emails should be fully customizable with no watermarks
- This is the same system that will eventually be used for password resets
- The framework should be popular and trusted as to not impose security concerns