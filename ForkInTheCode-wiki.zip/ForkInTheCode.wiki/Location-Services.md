One of the big challenges facing this project is a detailed location service for finding jobs
nearby and gathering needed skills from those results.  This page discusses how that may
be implemented although a lot more research will need to be done. 

- **Author**: Alex Wilkes <[adw4236@rit.edu](mailto:adw4236@rit.edu)>

# Location Services
At the moment, the application simply matches zipcodes to determine location.  While this is
sufficient for a proof of concept, this application aims to be more than just that.  Instead,
the user should have the ability to enter a full address and find jobs that are close to
them much like any other job acquisition platform does.

## Frontend Considerations
The user experience is paramount when location is involved.  The location search should have
the ability to auto fill when the user allows a browser (or cellular device) to read their
location.  If it is not automatically filled, there should only be one search bar instead
of having to fill out an entire form just for an address.

The search bar could take multiple formats of text and convert it to anything from an exact
address, general zip code, or state and convert it into a location that is searchable.

When entering a location for a Job Posting (or course), it could provide some suggestions
based on the location(s) that are associated with the organization in question.  This would
act as a dropdown that would have several options by default, but still be an input box that
the user could type in to override any of the drop-down options.

There should be adequate input validation for all of these inputs relevant to the location
services.

## Backend Considerations
There will have to be some data structure that stores addresses in the backend and is used to
transfer addresses to and from the frontend.  This data structure will likely be dictated by
whatever library that is chosen, but it must also support saving data in a NoSQL (and preferably
SQL) database.

This location must also support online which can be shown as results to any user no matter the
address they type in.

JobPostings themselves should likely maintain a reference to their location because it is likely
an organization may have multiple sites or have a remote job.  In this case we cannot guarantee
that the location is an entry in the Organization itself.  The organization location as mentioned
above will likely just be a convenience for the user to allow some auto-filling.
