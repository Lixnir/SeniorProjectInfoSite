# [Overview](https://github.com/Lixnir/ForkInTheCode/wiki)

- [Domain Definition](https://github.com/Lixnir/ForkInTheCode/wiki/Domain-Definition)
- [Other Resources](https://github.com/Lixnir/ForkInTheCode/wiki/Resource-Directory)
- [Wiki Meta Information](https://github.com/Lixnir/ForkInTheCode/wiki/Meta-Wiki)

# Requirements

- [Requirements Gathering](https://github.com/Lixnir/ForkInTheCode/wiki/Requirements-Gathering)
- [Templates](https://github.com/Lixnir/ForkInTheCode/wiki/Requirements-Templates)
- Functional Requirements
  - [Authentication](https://github.com/Lixnir/ForkInTheCode/wiki/Requirements-Functional-Authentication)
  - [Courses](https://github.com/Lixnir/ForkInTheCode/wiki/Requirements-Functional-Courses)
  - [Job Posting](https://github.com/Lixnir/ForkInTheCode/wiki/Requirements-Functional-Job-Posting)
  - [Job Search](https://github.com/Lixnir/ForkInTheCode/wiki/Requirements-Functional-Job-Search)
  - [Profile](https://github.com/Lixnir/ForkInTheCode/wiki/Requirements-Functional-Profile)
  - [Skills](https://github.com/Lixnir/ForkInTheCode/wiki/Requirements-Functional-Skills)
- Non-Functional Requirements
  - [Accessibility](https://github.com/Lixnir/ForkInTheCode/wiki/Requirements-Non-Functional-Accessibility)
  - [Performance](https://github.com/Lixnir/ForkInTheCode/wiki/Requirements-Non-Functional-Performance)
  - [Security](https://github.com/Lixnir/ForkInTheCode/wiki/Requirements-Non-Functional-Security)

# Processes

- [Roles](https://github.com/Lixnir/ForkInTheCode/wiki/Roles)
- [Bug Reporting](https://github.com/Lixnir/ForkInTheCode/wiki/Bug-Reporting)
- [Github Merging Guide](https://github.com/Lixnir/ForkInTheCode/wiki/Github-Merging-Guide)
- [Sprints and Backlog Grooming](https://github.com/Lixnir/ForkInTheCode/wiki/Sprints-and-Sprint-Planning)
- [Branching and Merging Strategies](https://github.com/Lixnir/ForkInTheCode/wiki/Branching-And-Merging-Strategies#bug-branches)
- [API and Design Definition](https://github.com/Lixnir/ForkInTheCode/wiki/API-and-Design-Definition)

# Project Setup

- [Development Enviornment](https://github.com/Lixnir/ForkInTheCode/wiki/Development-Environment)
- [Azure Cloud Setup](https://github.com/Lixnir/ForkInTheCode/wiki/Azure-Cloud-Setup)
- [Source Control Setup](https://github.com/Lixnir/ForkInTheCode/wiki/Source-Control-Setup)
- [Risk Mitigation](https://github.com/Lixnir/ForkInTheCode/wiki/Risk-Mitigation)

# [Project Structure](https://github.com/Lixnir/ForkInTheCode/wiki/Project-Structure)

- [Client](https://github.com/Lixnir/ForkInTheCode/wiki/Client-Side-Project-Structure)
- [Server](https://github.com/Lixnir/ForkInTheCode/wiki/Server-Side-Project-Structure)

# Code Architecture and Design

- [Architecture Overview](https://github.com/Lixnir/ForkInTheCode/wiki/Architecture-Overview)
- [Client](https://github.com/Lixnir/ForkInTheCode/wiki/Client-Side-Architecture)
- [Server](https://github.com/Lixnir/ForkInTheCode/wiki/Server-Side-Architecture)
  - [Model Tier Documentation](https://github.com/Lixnir/ForkInTheCode/wiki/Model-Tier-Documentation)

# Testing Strategies

- [UI Testing](https://github.com/Lixnir/ForkInTheCode/wiki/UI-Testing)
- [Server Testing](https://github.com/Lixnir/ForkInTheCode/wiki/Server-Testing)

# Future Plans

- [Database Migration](https://github.com/Lixnir/ForkInTheCode/wiki/Database-Migration-Plan)
- [Azure Pricing Breakdown](https://github.com/Lixnir/ForkInTheCode/wiki/Azure-Pricing)
- [Additional User Workflows](https://github.com/Lixnir/ForkInTheCode/wiki/User-Workflows)
- [Skill Aliases](https://github.com/Lixnir/ForkInTheCode/wiki/Skill-Aliases)
- [Pagination](https://github.com/Lixnir/ForkInTheCode/wiki/Pagination)
- [Modal Portals](https://github.com/Lixnir/ForkInTheCode/wiki/Modal-Portals)
- [Merging User Types](https://github.com/Lixnir/ForkInTheCode/wiki/Merging-User-Types)
- [Location Services](https://github.com/Lixnir/ForkInTheCode/wiki/Locations-Services)
- [Email Verification](https://github.com/Lixnir/ForkInTheCode/wiki/Email-Verification)
- [Common Code](https://github.com/Lixnir/ForkInTheCode/wiki/Common-Code)
