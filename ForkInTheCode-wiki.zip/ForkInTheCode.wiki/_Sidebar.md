# [Overview](https://github.com/FiTRSkills/ForkInTheCode/wiki)

- [Domain Definition](https://github.com/FiTRSkills/ForkInTheCode/wiki/Domain-Definition)
- [Other Resources](https://github.com/FiTRSkills/ForkInTheCode/wiki/Resource-Directory)
- [Wiki Meta Information](https://github.com/FiTRSkills/ForkInTheCode/wiki/Meta-Wiki)

# Requirements

- [Requirements Gathering](https://github.com/FiTRSkills/ForkInTheCode/wiki/Requirements-Gathering)
- [Templates](https://github.com/FiTRSkills/ForkInTheCode/wiki/Requirements-Templates)
- Functional Requirements
  - [Authentication](https://github.com/FiTRSkills/ForkInTheCode/wiki/Requirements-Functional-Authentication)
  - [Courses](https://github.com/FiTRSkills/ForkInTheCode/wiki/Requirements-Functional-Courses)
  - [Job Posting](https://github.com/FiTRSkills/ForkInTheCode/wiki/Requirements-Functional-Job-Posting)
  - [Job Search](https://github.com/FiTRSkills/ForkInTheCode/wiki/Requirements-Functional-Job-Search)
  - [Profile](https://github.com/FiTRSkills/ForkInTheCode/wiki/Requirements-Functional-Profile)
  - [Skills](https://github.com/FiTRSkills/ForkInTheCode/wiki/Requirements-Functional-Skills)
- Non-Functional Requirements
  - [Accessibility](https://github.com/FiTRSkills/ForkInTheCode/wiki/Requirements-Non-Functional-Accessibility)
  - [Performance](https://github.com/FiTRSkills/ForkInTheCode/wiki/Requirements-Non-Functional-Performance)
  - [Security](https://github.com/FiTRSkills/ForkInTheCode/wiki/Requirements-Non-Functional-Security)

# Processes

- [Roles](https://github.com/FiTRSkills/ForkInTheCode/wiki/Roles)
- [Bug Reporting](https://github.com/FiTRSkills/ForkInTheCode/wiki/Bug-Reporting)
- [Github Merging Guide](https://github.com/FiTRSkills/ForkInTheCode/wiki/Github-Merging-Guide)
- [Sprints and Backlog Grooming](https://github.com/FiTRSkills/ForkInTheCode/wiki/Sprints-and-Sprint-Planning)
- [Branching and Merging Strategies](https://github.com/FiTRSkills/ForkInTheCode/wiki/Branching-And-Merging-Strategies#bug-branches)
- [API and Design Definition](https://github.com/FiTRSkills/ForkInTheCode/wiki/API-and-Design-Definition)

# Project Setup

- [Development Enviornment](https://github.com/FiTRSkills/ForkInTheCode/wiki/Development-Environment)
- [Azure Cloud Setup](https://github.com/FiTRSkills/ForkInTheCode/wiki/Azure-Cloud-Setup)
- [Source Control Setup](https://github.com/FiTRSkills/ForkInTheCode/wiki/Source-Control-Setup)
- [Risk Mitigation](https://github.com/FiTRSkills/ForkInTheCode/wiki/Risk-Mitigation)

# [Project Structure](https://github.com/FiTRSkills/ForkInTheCode/wiki/Project-Structure)

- [Client](https://github.com/FiTRSkills/ForkInTheCode/wiki/Client-Side-Project-Structure)
- [Server](https://github.com/FiTRSkills/ForkInTheCode/wiki/Server-Side-Project-Structure)

# Code Architecture and Design

- [Architecture Overview](https://github.com/FiTRSkills/ForkInTheCode/wiki/Architecture-Overview)
- [Client](https://github.com/FiTRSkills/ForkInTheCode/wiki/Client-Side-Architecture)
- [Server](https://github.com/FiTRSkills/ForkInTheCode/wiki/Server-Side-Architecture)
  - [Model Tier Documentation](https://github.com/FiTRSkills/ForkInTheCode/wiki/Model-Tier-Documentation)

# Testing Strategies

- [UI Testing](https://github.com/FiTRSkills/ForkInTheCode/wiki/UI-Testing)
- [Server Testing](https://github.com/FiTRSkills/ForkInTheCode/wiki/Server-Testing)

# Future Plans

- [Database Migration](https://github.com/FiTRSkills/ForkInTheCode/wiki/Database-Migration-Plan)
- [Azure Pricing Breakdown](https://github.com/FiTRSkills/ForkInTheCode/wiki/Azure-Pricing)
- [Additional User Workflows](https://github.com/FiTRSkills/ForkInTheCode/wiki/User-Workflows)
- [Skill Aliases](https://github.com/FiTRSkills/ForkInTheCode/wiki/Skill-Aliases)
- [Pagination](https://github.com/FiTRSkills/ForkInTheCode/wiki/Pagination)
- [Modal Portals](https://github.com/FiTRSkills/ForkInTheCode/wiki/Modal-Portals)
- [Merging User Types](https://github.com/FiTRSkills/ForkInTheCode/wiki/Merging-User-Types)
- [Location Services](https://github.com/FiTRSkills/ForkInTheCode/wiki/Location-Services)
- [Email Verification](https://github.com/FiTRSkills/ForkInTheCode/wiki/Email-Verification)
- [Common Code](https://github.com/FiTRSkills/ForkInTheCode/wiki/Common-Code)
