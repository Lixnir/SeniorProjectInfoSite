# Requirements Documentation Templates

Originally we had intended to create both user stories and use cases for all of the requirements. When working on those we realized that since not every user story has a direct correlation to a use case and vice versa we instead decided to create a list of relavant information that is needed for every bit of functionality. In addition to condensing the location of relavant information, this also allows us to note down any information that is not explicitly defined in either of the other templates, and also makes it easier to be sure to significantly define functionality that might only appear as a side effect of a use case or user story (such as navigation).

## Template - for each function the user would need to do

### Why is this functionality needed?

Description

### Associated User Types aka User types that are able to perform this function - both to be sure that who needs to see it can see it, but also so that those who shouldn't be able to cannot

Either sentences or lists saying what user types relate or do not.

### Default Action Path aka default action path for the user to accomplish this function

Prerequirement:

1.

Postrequirement:

### Other Possible Branches

Branch requirement/reason for it being something different

- What would happen differently

### Front End UI Spec - link to the figma diagram with each possible visible change documented

[url text](actualUrl)

### Relevant API Calls aka List of API calls needed and each call explicitly defined - including name and type of route, data and types to be sent, data and types to be recieved, and any errors and/or relevant codes/status returns

/route - TYPE

Input: { object to be sent }

Possible Responses:

- Response code number: What that code means

  - Returned information/Error Response: either what would be sent in the data of a valid response or what the error message would be

Note: Any other notes such as if a input or output could only be a set list of results or any other information that is important but not specified above.

### Required Input Validation aka any input validation, defined for each input

Input label:

- Requirement 1
