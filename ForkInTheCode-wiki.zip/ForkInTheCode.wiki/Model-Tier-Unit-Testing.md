# Testing Philosophy
- Independently runnable tests
- Clean database each time
- 3 distinct sections (setup, execution, validation)
- Determining test cases

# Writing A Test
- Syntax
- Sytle Guidelines

## Testing Utils
- BeforeAll
- AfterAll
- BeforeEach

## Mocking & Dependencies
- Potential Mocking Frameworks

# Testing Configurations
- Configuration file (Shared with API testing)

## In Memory Database
- Separate configurations for this