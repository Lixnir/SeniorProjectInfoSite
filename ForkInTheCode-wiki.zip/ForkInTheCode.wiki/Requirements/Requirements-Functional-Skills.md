# Requirements - Skills

## Search for and Select a Skill

### Why is this functionality needed?

In multiple locations the ability to find a specific skill is needed, for example when searching for a job or when adding a skill directly on the profile.

### Associated User Types

Some user types can do this in different locations, and while everyone can't do this everywhere, anyone can do this somewhere.

### Default Action Path

Prerequirement: None

1. The user types the skill they want to select into the drop down.
2. The user select the skill that they want from the drop down.

Postrequirement: The selected skill is visually indicated.

### Other Possible Branches

None.

### Front End UI Spec

Example use, see Skills: [Job Search](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan's-Figma?node-id=123%3A0)

### Relevant API Calls

/skills - GET

Input: None

Possible Responses:

- Response code 200: Success

  - Returned information: [{ name: STRING, \_id: int }]

- Response code number: 400 - Bad Request

  - Returned information: { data: [error array] } The error array specifies the validation checks failed

- Response code number: 406 - Not Acceptable

  - Returned information: { skill does not exist }

Note: Any other notes such as if a input or output could only be a set list of results or any other information that is important but not specified above.

### Required Input Validation

None.

## Create a Skill

### Why is this functionality needed?

This allows educators and employers to create new skills to associate with their job postings and classes.

### Associated User Types

Only employers and educators can do this.

### Default Action Path

Prerequirement: None

1. The user types the skill they want to create into the drop down.
2. The user clicks "Create Skill".
3. The user inputs the name of the skill and a description for the skill.
4. The user selects "Create".

Postrequirement: The new skill has been created is also included in the selection.

### Other Possible Branches

Cancels creation

- If the user cancels creating the skill nothing is saved and they are returned to the state before step 2.

Skill already exists

- If the user tries to create a skill that already exists an error will appear saying that it already exists.

### Front End UI Spec

Example use, see the Skills section: [Add Course](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan's-Figma?node-id=240%3A1)

### Relevant API Calls

/skills/createSkill - POST

Input: { name: STRING, description: STRING }

Possible Responses:

- Response code 200: Success

  - Returned information: { \_id: STRING }.

- Response code 400: Bad Request

  - Returned information: "Skill with that name already exists."

- Response code 400: Bad Request

  - Returned information: "Error on skill creation."

- Response code 400: Bad Request

  - Returned information: "Invalid usertype."

Note: Any other notes such as if a input or output could only be a set list of results or any other information that is important but not specified above.

### Required Input Validation

Name:

- Must be a skill that doesn't already exist

## Search based on zip code zone

### Why is this functionality needed?

This allows users to search for skills that are in demand in their local area, or in an area they might be moving to or similar.

### Associated User Types

All user types can do this.

### Default Action Path

Prerequirement: User is on the Skills Search page.

1. User types in their zip code.
2. User clicks the search button.

Postrequirement: The user is able to see all skills associated with jobs located near their location, as well as the number of jobs associated with each skill.

### Other Possible Branches

Allow for Search Radius

- After step 1: User selects the search radius.
- This would include all jobs within the specified radius versus just jobs in the specified zip code in the search results.

### Front End UI Spec

[Skills Search](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan's-Figma?node-id=147%3A0)

### Relevant API Calls

/skills/search/ - GET

Input: { zipCode: STRING, organization: STRING }

Possible Responses:

- Response code number: 200 - Success

  - Returned information: { data: [{ name: STRING, numJobs: int, \_id: int}] }

- Response code number: 400 - Bad Request

  - Returned information: { data: [error array] } The error array specifies the validation checks failed

Note: Any other notes such as if a input or output could only be a set list of results or any other information that is important but not specified above.

Note: Both zipCode and organization are optional, in this specific instance zipCode would always be included.

Note: This might eventually be changed to include a distance from a zip code in the call, but since that is not in the MVP it is not included here.

### Required Input Validation

Zip Code:

- Must be a 5 digit number

## Search based on organization

### Why is this functionality needed?

This way a user is able to look for skills in demand for a specific organization, for instance if they are looking for skills needed at a company they already work at or similar.

### Associated User Types

All user types can do this.

### Default Action Path

Prerequirement: User is on the Skills Search page.

1. User selects Organization.
2. User types in the organization.
3. User clicks the search button.

Postrequirement: The user is able to see all skills associated with jobs from the specified organization, as well as the number of jobs with that skill from that organization.

### Other Possible Branches

None known at this time

- None known at this time

### Front End UI Spec

[Skill Search](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan's-Figma?node-id=147%3A0)

### Relevant API Calls

See: Functional Requirements - Skills - Search based on zip code zone

Note: In this instance the optional parameter "organization" would always be included

### Required Input Validation

Organization:

- Must be an existing organization

## Add Skills to Profile from Search

### Why is this functionality needed?

This allows users to add skills to their profile once they have figured out what skills are in demand in their area.

### Associated User Types

Only Job Seekers can add skills to their profile.

### Default Action Path

Prerequirement: User has done a search for skills and is viewing the results of said search.

1. User clicks the checkbox associated with any skill that they would want to add.
2. User clicks "Add Skills to Profile".

Postrequirement: The skills selected are now associated with the user's profile and the associated checkbox is now checked but disabled.

### Other Possible Branches

None known at this time

- None known at this time

### Front End UI Spec

[Skills Search](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan's-Figma?node-id=147%3A0)

### Relevant API Calls

See: Functional Requirements - Profile - "Job Seeker - Add Skill"

### Required Input Validation

No user input validation required

## View Individual Skill Information

### Why is this functionality needed?

The user is able to see more details on a specific skill so that they understand what that actual skill means and requires.

### Associated User Types

All user types can do this.

### Default Action Path

Prerequirement: User has done a search for skills and is viewing the results of said search.

1. User clicks the name of a specific skill.

Postrequirement: The user is able to see a description, aliases, and associated courses in relation to the selected skill.

### Other Possible Branches

User navigates from a direct URL instead of from a search.

- Instead of step 1. the user would type in the url associated with a specific skill and result in the same postrequirement.

User navigates from a Job Posting.

- Instead of step 1. the user would select the skill from the job posting and result in the same postrequirement.

User navigates from a Course.

- Instead of step 1. the user would select the skill from the course and result in the same postrequirement.

User navigates from the Profile.

- Instead of step 1. the user would click the skill in the Profile and result in the same postrequirement.

### Front End UI Spec

[Skills Detail](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan's-Figma?node-id=170%3A13)

### Relevant API Calls

/skills/getSkill/{id} - GET

Input: None

Possible Responses:

- Response code number: 200 - Success

  - Returned information: { skill: { name: STRING, description: STRING, alias: [ STRING ] }, courses: [ COURSE ]}

- Response code number: 400 - Bad Request

  - Returned information: { data: [error array] } The error array specifies the validation checks failed

- Response code number: 406 - Not Acceptable

  - Returned information: { skill does not exist }

Note: Any other notes such as if a input or output could only be a set list of results or any other information that is important but not specified above.

### Required Input Validation

Skill Id:

- Must be a valid skill id

## Toggle Showing Already Added Skills

### Why is this functionality needed?

The user can choose to see the skills they have already added so they can see their skills in relation to the skill popularity, but also they can choose to not show their already selected skills if they so wish.

### Associated User Types

Job Seekers can do this.

### Default Action Path

Prerequirement: User has done a search for skills and is viewing the results of said search.

1. The user selects the "include skills in profile" toggle.

Postrequirement: The user is either not able to or is able to see the skills that are already on their profile based on which way the toggle is.

### Other Possible Branches

User has not made a search yet.

- The only difference would be that nothing would change on toggle, but when a user makes a search the toggle would be properly applied to the results.

### Front End UI Spec

[Skills Search](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan's-Figma?node-id=147%3A0)

### Relevant API Calls

There is no API call associated with this requirement. The closest would be the two skills search calls, but this filtering will be done on the front end not through a backend call.

### Required Input Validation

N/A

## Add Skills to Job Search from Search

### Why is this functionality needed?

This allows users to add skills to their profile once they have figured out what skills are in demand in their area.

### Associated User Types

Only unauthenticated users can do this.

### Default Action Path

Prerequirement: User has done a search for skills and is viewing the results of said search.

1. User clicks the checkbox associated with any skill that they would want to add.
2. User clicks "Add Skills to Job Search".

Postrequirement: The user is navigated to the Job Search page and the skills selected are automatically filled into the search.

### Other Possible Branches

None known at this time

- None known at this time

### Front End UI Spec

[Skills Search](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan's-Figma?node-id=147%3A0)

### Relevant API Calls

See: Functional Requirements - Skills - Search based on zip code zone

### Required Input Validation

No user input validation required
