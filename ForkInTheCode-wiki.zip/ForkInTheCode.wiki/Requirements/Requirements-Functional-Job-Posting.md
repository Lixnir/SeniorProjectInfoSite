# Requirements - Job Posting

## Overview

Information associated with a job posting, ? indicates that that attribute is optional:
Job Posting Object -

```
{
  _id: STRING,
  jobTitle: STRING,
  zipCode: STRING,
  salary?: STRING,
  skills: [ SKILL ],
  responsibilities?: STRING,
  organization: ORGANIZATION,
  description: STRING,
  benefits?: STRING,
  courses?: [ COURSE ],
  amountOfJobs?: STRING,
  jobTimeline?: STRING,
}
```

Note: the \_id attribute is generated in the backend.

## View Own Job Postings

### Why is this functionality needed?

This way employers are able to view the job postings that they have created.

### Associated User Types

Only Employers can view only their own Job Postings.

### Default Action Path

Prerequirement: An employer is logged in.

1. User clicks on View Job Postings

Postrequirement: The user is navigated to a page and is able to see a quick summary of information on all Job Postings they have created.

### Other Possible Branches

User attempting to access this page is not an authenticated Employer

- If they are authenticated just not an employer they would go to Skill Search, and if they are not authenticated they would go to Login.

### Front End UI Spec

[Here](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan-s-Figma?node-id=467%3A3)

### Relevant API Calls

/jobPostings - GET

Input: None

Possible Responses:

- Response code 200: Success

  - Returned information: [ JOBPOSTING ]

- Response code 400: Something went wrong searching for this org's postings

  - Returned information: "Issue retrieving jobpostings."

- Response code 400: User is not an employer

  - Returned information: "Invalid usertype to view job postings."

### Required Input Validation

N/A

## Edit Job Posting

### Why is this functionality needed?

This way employers are able to edit any job posting they have previously created in case something has changed for whatever reason.

### Associated User Types

Only Employers can edit only their own Job Postings.

### Default Action Path

Prerequirement: An employer is logged in and is viewing their job postings.

1. User clicks on edit associated with a specific Job Posting.
2. User changes/adds whatever information they want.
3. User clicks submit.

Postrequirement: The user is returned to the view job posting page and is able to see the updated posting.

### Other Possible Branches

User inputs invalid information and tries to submit

- The invalid information would be specified, nothing would be saved, and the user would not change pages.

User cancels edit

- The user would be returned to the view job postings page without any changes being saved.

### Front End UI Spec

[Here](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan-s-Figma?node-id=468%3A207)

### Relevant API Calls

/jobPosting - GET

Input: { id: STRING }

Possible Responses:

- Response code 200: Success

  - Returned information: { JOBPOSTING } that has that specific id

- Response code 400: Something went wrong searching for this org's posting

  - Returned information: "Issue retrieving jobposting."

- Response code 400: jobposting is not the user's

  - Returned information: "User does not own this jobposting."

- Response code 400: user is not employer

  - Returned information: "Invalid usertype to view job postings."

/jobPosting - PATCH

Input: { JOBPOSTING }

Possible Responses:

- Response code 200: Success

  - Returned information: Nothing of relevance.

- Response code 400: jobposting is not the user's

  - Returned information: "User does not own this jobposting."

- Response code 400: user is not employer

  - Returned information: "Invalid usertype."

- Response code 400: jobposting editing failed

  - Returned information: "Error editing jobposting."

Note: Anything that is sent back in the JOBPOSTING object is how it should be after the edits, so nothing is needed to turn that object into just the edits.
Note: @Backend

### Required Input Validation

/jobPosting - GET - id:

- id must be a valid jobPosting that the validated user has created

/jobPosting - PATCH:

- required fields must exist
- all skills are valid skills
- the courses are valid courses

## Delete Job Posting

### Why is this functionality needed?

This way employers are able to delete any job posting they have previously created that is not accepting applications anymore for whatever reason.

### Associated User Types

Only Employers can delete only their own Job Postings.

### Default Action Path

Prerequirement: An employer is logged in and is viewing their job postings.

1. User clicks on delete associated with a specific Job Posting.
2. User confirms deletion in the popup confirmation dialogue.

Postrequirement: The user is returned to the view job posting page and is able to see the updated posting.

### Other Possible Branches

User selects cancel when viewing the confirmation dialogue

- The popup would close and nothing would be changed.

### Front End UI Spec

[Here](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan-s-Figma?node-id=467%3A0)

### Relevant API Calls

/jobPosting - DELETE

Input: { id: STRING }

Possible Responses:

- Response code 200: Success

  - Returned information: Nothing of relevance.

- Response code 400: jobposting is not the user's

  - Returned information: "User does not own this jobposting."

- Response code 400: user is not employer

  - Returned information: "Invalid usertype."

- Response code 400: jobposting deleting failed

  - Returned information: "Error deleting jobposting."

Note: @Backend

### Required Input Validation

/jobPosting - DELETE - id:

- id must be a valid jobPosting that the validated user has created

## Add Job Posting

### Why is this functionality needed?

This way employers are able to add new job postings.

### Associated User Types

Only Employers can add Job Postings.

### Default Action Path

Prerequirement: An employer is logged in and is viewing their job postings.

1. User clicks on Add Job Posting.
2. User inputs all required information and any optional information that they want.
3. User clicks Add.

Postrequirement: The user is returned to the view job posting page and is able to see the new job posting.

### Other Possible Branches

User inputs invalid information and tries to submit

- The invalid information would be specified, nothing would be saved, and the user would not change pages.

User cancels adding

- The user would be returned to the view job postings page without any changes being saved.

### Front End UI Spec

[Here](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan-s-Figma?node-id=468%3A24)

### Relevant API Calls

/jobPosting - POST

Input: { JOBPOSTING } - not including \_id or organization

Possible Responses:

- Response code 200: Success

  - Returned information: Nothing of relevance.

- Response code 400: jobposting creation failed, most likely on skills

  - Returned information: "Error adding skills."

- Response code 400: jobposting creation failed

  - Returned information: "Error eon jobposting creation."

- Response code 400: user is not an employer

  - Returned information: "Invalid usertype."

### Required Input Validation

/jobPosting - POST:

- required fields must exist
- all skills are valid skills
- the organization is a valid organization
- the courses are valid courses

## Add Course to Job Posting

### Why is this functionality needed?

This way employers are able to specify which courses are sure to fulfil the skill requirement in their job posting.

### Associated User Types

Only Employers can add courses to only their own Job Postings.

### Default Action Path

Prerequirement: An employer is logged in and is currently editing a job posting or creating a new one.

1. User clicks on Add Course to Job Posting.
2. A popup shows up and the user is able to search for courses based on their name, already auto filtered by skills in job posting.
3. User is able to add one or more courses that show up in the popup.

Postrequirement: The user is returned to the edit or add job posting page and is able to see the list of courses that will be associated with that job posting.

### Other Possible Branches

None

### Front End UI Spec

[Here](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan-s-Figma?node-id=468%3A24)

### Relevant API Calls

/courses/search - GET

Input: { skills: [ SKILL ], searchValue: STRING}

Possible Responses:

- Response code 200: Success

  - Returned information: [ COURSE ]

Note: searchValue will be whatever was input by the user into the search box, the results should only include courses that have that string in their title somewhere (DEV NOTE: should this also include in the description?)
Note: @Backend

### Required Input Validation

/courses/search:

- all skills are valid skills
