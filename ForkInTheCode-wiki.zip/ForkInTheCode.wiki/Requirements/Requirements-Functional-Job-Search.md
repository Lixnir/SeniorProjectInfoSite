# Requirements - Job Search

Note: due to the order of development and when we decided to define requirements like this, Job Search doesn't have templated out requirements and was done almost entirely through individual communication. The following list is the 3 functions that we decided should be written out but did not get to due to continuing development taking priority.

- Search by Zip Code and Skills
- View Individual Job Posting
- Autopopulate skills for Job Seekers
