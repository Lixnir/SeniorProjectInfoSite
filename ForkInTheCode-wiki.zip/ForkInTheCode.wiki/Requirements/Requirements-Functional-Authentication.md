# Requirements - Authentication

## Login

### Why is this functionality needed?

This allows users to have information that they have put in before saved and only they can see it.

### Associated User Types

Any unauthenticated user can log in. All user types are possible results after login.

### Default Action Path

Prerequirement: No user is logged in.

1. The user clicks the "LOG IN" button in the navigation bar.
2. The user enters their email and password.
3. The user clicks the "SIGN IN" button.

Postrequirement: The user is logged in.

- As Job Seeker: The user is on the Job Search page.
- As Employer: The user is on the _TBD_ page.
- As Educator: The user is on the _TBD_ page.

### Other Possible Branches

If email and password entered do not correlate to an account:

- An error will appear saying that the email and/or password was incorrect.
- The user is not redirected and is not logged in.

If the email or password is not entered and "SIGN IN" is clicked:

- A popup will appear saying that the empty field is required
- The user is not redirected and is not logged in.

If the email does not adhere to the input validation defined below and "SIGN IN" is clicked:

- A popup will appear saying that the email field is incorrect and say what is incorrect about it
- The user is not redirected and is not logged in.

### Front End UI Spec

[Login](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan's-Figma?node-id=17%3A2)

### Relevant API Calls

/login - POST

Input: { "email": STRING, "password": STRING }

Possible Responses:

- 200: Valid Login

  - Returned information: STRING

- 401: Invalid Login Attempt

  - Error Response: "Unauthorized"

Note: The returned information for a valid login is the user type of the user that logged in. Possible responses are: "JobSeekerProfile", "EmployerProfile", or "EducatorProfile".

### Required Input Validation

Email:

- Exists

- Valid email, including "@" and "."

Password:

- Exists

## Sign Up

### Why is this functionality needed?

This allows new users to be able to create accounts to save information for future use.

### Associated User Types

Job Seekers, Employers, and Educators can all sign up for accounts.

### Default Action Path

Prerequirements: There is no user signed in.

1. The user clicks "SIGN UP" in the navigation bar OR the user clicks "Don't have an account? Sign Up" from the Sign In page.

If the user wants to sign up as a Job Seeker:

2. The user inputs their desired email and password.
3. The user clicks the "SIGN UP" button.

If the user wants to sign up as an Employer or Educator:

2. The user inputs their desired email, password, and their associated organization.
3. The user clicks the "SIGN UP" button.

Postrequirement:

- The user is now logged in with the newly created account.

If the user wants to sign up as a Job Seeker:

- The user is navigated to the Skills Search page.

If the user wants to sign up as an Employer or Educator:

- The user is navigated to the _TBD_ page.

### Other Possible Branches

The user enters an email that already has an associated account and clicks "SIGN UP":

- An error would show up saying that a user with that email is already registered
- The user would not be logged in or leave that page

The user enters an email, password, or organization that does not follow the input validation requirements defined below and clicks "SIGN UP":

- An error would show up for the invalid field saying why that field is invalid
- The user would not be logged in or leave that page

### Front End UI Spec

[Job Seeker Sign Up](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan's-Figma?node-id=219%3A100)
[Educator Sign Up](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan's-Figma?node-id=219%3A29)
[Employer Sign Up](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan's-Figma?node-id=4%3A30)

### Relevant API Calls

/register - POST

Input: { "usertype": STRING, "email": STRING, "password": STRING }

Possible Responses:

- 200: Valid Registration

  - Returned information: "Successfully created [user type] user"

- 400: Not Valid Registration

  - Error Response: {"name": "UserExistsError", "message": "A user with the given email is already registered"}

Note: The input "usertype" can only be "JobSeekerProfile", "EmployerProfile", or "EducatorProfile". There is a possibility of a different error being thrown on a status 400 response, it would have a different string value for both "name" and "message".

### Required Input Validation

Email:

- Exists
- Valid email, including "@" and "."

Password:

- Exists
- Other password requirements _TBD_

Organization:

- Exists
- Other organization requirements _TBD_

## Log Out

### Why is this functionality needed?

So that the user can be sure that if they are done looking at their information then no one else who would get on the same computer could access it, or so that a different user could look at their information instead on the same computer.

### Associated User Types

Job Seekers, Employers, and Educators can all sign up for accounts.

### Default Action Path

Prerequirement: There is a user logged in.

1. The user clicks on "SIGN OUT" in the navigation bar.

Postrequirement: The user is not logged in anymore, and they are redirected to the "Sign In" page.

### Other Possible Branches

No other branches.

### Front End UI Spec

None. Only front end requirement is a logout button defined in the navigation bar.

### Relevant API Calls

/logout - GET

Input: None

Possible Responses:

- 200: Successfully Logged Out

  - Returned information: "Successfully logged out"

### Required Input Validation

None

## Persistent Login

### Why is this functionality needed?

This way users do not have to log in every time that they leave the site and come back to it if they did not log out. They also don't have to worry about oddly being logged out if they refresh the page.

### Associated User Types

Job Seekers, Employers, and Educators can all sign up for accounts.

### Default Action Path

Prerequirement: The user is not logged in. The user has logged in recently and not manually logged out.

1. The user activates something that requires information on their authentication status.

Postrequirement: The user is logged in and the request for information relating to authentication proceeds with them properly authenticated.

### Other Possible Branches

The user has not logged in recently or has manually logged out since their last log in.

- The user would not be logged in and the request for authentication would reflect their unauthenticated status.

### Front End UI Spec

None

### Relevant API Calls

/profile/usertype - GET

Input: None

Possible Responses:

- 200: There is a user who has been logged in and has been reauthenticated

  - Returned Information: STRING

- 400: There is no user that should be reauthenticated.

  - Error Message: "Access Denied."

Note: The returned information is a string reflecting the usertype of the user that was reauthenticated. It can only be "JobSeekerProfile", "EmployerProfile", or "EducatorProfile".

### Required Input Validation

None
