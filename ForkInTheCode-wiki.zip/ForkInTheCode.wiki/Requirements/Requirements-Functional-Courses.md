# Requirements - Courses

## Overview

Information associated with a course, ? indicates that that attribute is optional:
{
\_id: STRING,
location: STRING,
name: STRING,
skills: [ SKILL ],
organization: ORGANIZATION,
contact?: STRING,
period?: STRING,
times?: STRING,
description?: STRING,
moneyCost?: STRING,
timeCost?: STRING,
requiredEquipment?: STRING,
}

Note: the \_id attribute is generated in the backend

## Adding a course

### Why is this functionality needed?

This allows educators to add courses to be able to be used in the rest of the system.

### Associated User Types

Only educators can add courses.

### Default Action Path

Prerequirement: An educator is signed in.

1. User navigates to "Course Manager".
2. User selects "Add Course".
3. User types in the course name and course location.
4. User selects associated skills.
5. User selects "Add Course".

Postrequirement: The educator can see the new class and associated information in their list of created classes.

### Other Possible Branches

User cancels Add Course

- Instead of step 5. the user would cancel adding the course.
- Postrequirement: No new class has been added and the input data would not be saved.

User inputs invalid information

- If the user has put invalid information and selects Add Course in step 4 instead they would be shown what information is incorrect and would be returned to step 3 with no information saved.

User adds optional information

- After step 4. the user would be able to enter in information relation to any of the optional values included in the course object definition at the top of this document.

### Front End UI Spec

[Add Course](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/FiTR-Mockups?node-id=240%3A1)

### Relevant API Calls

/courses/course - POST

Input: { location: STRING, name: STRING, skills: [ SKILL ], contact?: STRING, period?: STRING, times?: STRING, description?: STRING, moneyCost?: STRING, timeCost?: STRING, requiredEquipment?: STRING, }

Possible Responses:

- Response code 200: Success

  - Returned information: Successfully created course.

- Response code number: 400 - Bad Request

  - Returned information: { data: [error array] } The error array specifies the validation checks failed

- Response code number: 400 - Bad Request

  - Returned information: Access Denied.

- Response code number: 400 - Bad Request

  - Returned information: Invalid usertype. (Only Educator can access this method)

- Response code number: 400 - Bad Request

  - Returned information: Error adding skills. (skill ids either cannot be found or cannot be casted)

- Response code number: 400 - Bad Request

  - Returned information: Error on course creation. (Something went wrong creating a course in general, error on server is console.logged)

Note: ? next to an attribute name means it is an optional attribute.

### Required Input Validation

Skills:

- Must be a list of all valid skills

## Edit a course

### Why is this functionality needed?

This allows the educator to be able to alter the data if anything is either entered incorrectly or if it changes for whatever reason.

### Associated User Types

Only educators can edit courses, and only their own courses.

### Default Action Path

Prerequirement: An educator is signed in and has previously created a course.

1. User selects edit on a specific course.
2. User changes whatever information needs to be changed.
3. User selects "Confirm Edit".

Postrequirement: The changes are properly reflected to the educator when viewing the changed course and properly saved in the database.

### Other Possible Branches

User cancels edit

- Instead of step 3. the user selects cancel edit.
- Postrequirement: Any changes are undone and no changes are saved.

User edits information to invalid information

- If the user enters invalid information and does step 3. they would be shown what information is invalid and would be returned to step 2 with no information saved.

### Front End UI Spec

[Edit Course](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/FiTR-Mockups?node-id=241%3A42)

### Relevant API Calls

/courses/course - PATCH

Input: { \_id: STRING, location?: STRING, name?: STRING, skills?: [ SKILL ], contact?: STRING, period?: STRING, times?: STRING, description?: STRING, moneyCost?: STRING, timeCost?: STRING, requiredEquipment?: STRING, }

Possible Responses:

- Response code 200: Success

  - Returned information: Successfully updated course.

- Response code number: 400 - Bad Request

  - Returned information: { data: [error array] } The error array specifies the validation checks failed

- Response code number: 400 - Bad Request

  - Returned information: Access Denied.

- Response code number: 400 - Bad Request

  - Returned information: Invalid usertype.

- Response code number: 400 - Bad Request

  - Returned information: Error adding skills.

- Response code number: 400 - Bad Request

  - Returned information: Error editing course.

Note: ? next to an attribute name means it is an optional attribute.

Note: To delete something return either an empty string or empty array as makes sense, if an attribute is not included then it should not change.

### Required Input Validation

Skills:

- Must be a list of all valid skills

## Delete a course

### Why is this functionality needed?

Allows the educator to remove a course that they are no longer offering.

### Associated User Types

Only educators can delete courses, and only their own courses.

### Default Action Path

Prerequirement: An educator is signed in and has previously created a course.

1. User select delete a course
2. User selects confirm on a confirmation dialogue.

Postrequirement: The deleted course is no longer shown, is removed from the database, and is not shown to anyone anymore.

### Other Possible Branches

User selects cancel on the confirmation dialogue

- Instead of selecting confirm in step 2. the user selects cancel
- Postrequirement: The course is not deleted and no data changes.

### Front End UI Spec

[View Courses](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/FiTR-Mockups?node-id=240%3A0)

### Relevant API Calls

/courses/course - DELETE

Input: { \_id: STRING }

Possible Responses:

- Response code 200: Success

  - Returned information: Successfully deleted course.

- Response code number: 400 - Bad Request

  - Returned information: { data: [error array] } The error array specifies the validation checks failed

- Response code number: 400 - Bad Request

  - Returned information: Access Denied.

- Response code number: 400 - Bad Request

  - Returned information: Invalid usertype.

- Response code number: 400 - Bad Request

  - Returned information: Error deleting course.

Note:

### Required Input Validation

None

## View all created courses

### Why is this functionality needed?

This allows educators to see all the courses they have created.

### Associated User Types

Only educators can see courses this way, and they can only see the courses they have created.

### Default Action Path

Prerequirement: An educator is signed in.

1. User navigates to "Course Manager".

Postrequirement: The educator can see a list of all of the classes with some associated information.

### Other Possible Branches

None

### Front End UI Spec

[View Courses](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/FiTR-Mockups?node-id=240%3A0)

### Relevant API Calls

/courses/ - GET

Input: None

Possible Responses:

- Response code 200: Success

  - Returned information: [ COURSE ]

- Response code number: 400 - Bad Request

  - Returned information: { data: [error array] } The error array specifies the validation checks failed

- Response code number: 400 - Bad Request

  - Returned information: Access Denied.

- Response code number: 400 - Bad Request

  - Returned information: Invalid usertype.

- Response code number: 400 - Bad Request

  - Returned information: Error getting courses.

Note: This call will only succeed if it is called when the logged in user is an educator and will only return their specific courses.

### Required Input Validation

None
