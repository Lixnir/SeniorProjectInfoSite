# Requirements - Profile

## Job Seeker - Overview

Information associated with a Job Seeker's profile, ? indicates that that attribute is optional:
Profile Object -

```
{
  firstname?: STRING,
  lastname?: STRING,
  dob?: DATE,
  skills?: [ SKILL ],
  career?: [ { jobTitle: STRING, startDate: DATE, endDate: DATE, organization: ORGANIZATION } ],
  education?: [ { degree: STRING, major: STRING, gradDate: DATE, organization: ORGANIZATION } ]
}
```

## Job Seeker - View Profile

### Why is this functionality needed?

This allows the job seeker to know what information is associated with them.

### Associated User Types

Only Job Seekers can see information this way.

### Default Action Path

Prerequirement: A Job Seeker is signed in.

1. The user clicks the "PROFILE" button in the navigation bar.

Postrequirement: The user will see the information associated with their profile.

### Other Possible Branches

No other branches.

### Front End UI Spec

[Profile](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan's-Figma?node-id=219%3A271)

### Relevant API Calls

/profile - GET

Input: None

Possible Responses:

- 200: There is a valid logged in user.

  - Returned Information: PROFILE

- 400: There is no logged in user or the user type associated with the current login is invalid.

  - Error Message: TBW

@Backend

### Required Input Validation

None

## Job Seeker - Add/Edit General Information

### Why is this functionality needed?

This allows the job seeker to add in additional information about themselves that is not included in the base sign up experience or alter information associated with themselves in case it was entered incorrectly or has changed.

### Associated User Types

Only Job Seekers can add information this way.

### Default Action Path

Prerequirement: A Job Seeker is signed in and is on their profile page.

1. User clicks the edit button associated with their overall profile information.
2. User adds/edits whatever information they would like.
3. User clicks Save.

Postrequirement: The user will see the information that they have added/edited correctly displayed.

### Other Possible Branches

User doesn't input all information

- In step 3 instead of clicking save the user clicks the edit button again, nothing will be saved and the original values will be shown.

### Front End UI Spec

[Edit Profile](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan's-Figma?node-id=28%3A8)

### Relevant API Calls

/profile - POST

Input: { "firstname": STRING, "lastname": STRING, "dob": DATE }

TBW - Possible Responses:

- Response code number: What that code means

  - Returned information/Error Response: either what would be sent in the data of a valid response or what the error message would be

Note: Any other notes such as if a input or output could only be a set list of results or any other information that is important but not specified above.

### Required Input Validation

dob:

- If it exists it must be a valid DATE

## Job Seeker - Add Career Information

### Why is this functionality needed?

This allows the job seeker to add careers that they have had to the information associated with them.

### Associated User Types

Only Job Seekers can add careers this way.

### Default Action Path

Prerequirement: A Job Seeker is signed in and is on their profile page.

1. User clicks the Add Career button.
2. User fills out the job title, start date, end date, and organization.
3. User clicks the Save button.

Postrequirement: The user will see the information that they have added displayed.

### Other Possible Branches

User inputs invalid or incomplete information

- After the user clicks save it would not save the information and would indicate the incorrect/incomplete information.

User cancels addition

- Instead of clicking Save the user would close the dialogue, and nothing would be saved.

### Front End UI Spec

[Edit Profile](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan's-Figma?node-id=28%3A8)

### Relevant API Calls

/profile/career - POST

Input: { jobTitle: STRING, endDate: DATE, startDate: DATE, organization: STRING }

TBW - Possible Responses:

- Response code number: What that code means

  - Returned information/Error Response: either what would be sent in the data of a valid response or what the error message would be

Note: Any other notes such as if a input or output could only be a set list of results or any other information that is important but not specified above.

### Required Input Validation

endDate/startDate:

- Must be valid dates
- endDate must always be after startDate

## Job Seeker - Edit Career Information

### Why is this functionality needed?

This allows the job seeker to edit careers that they have had in case it was entered incorrectly or has changed.

### Associated User Types

Only Job Seekers can edit careers this way.

### Default Action Path

Prerequirement: A Job Seeker is signed in and is on their profile page.

1. User clicks the edit button for the Careers section
2. User clicks the edit button for the individual career they want to edit
3. User changes whatever information they would like to change
4. User clicks the Update Career button

Postrequirement: The user will see the information that they have changed accurately displayed.

### Other Possible Branches

User inputs invalid or incomplete information

- After the user clicks Update Career it would not save the information and would indicate the incorrect/incomplete information.

User cancels addition

- Instead of clicking Update Career the user would click either the Career specific or overall Careers edit button, and nothing would be saved.

### Front End UI Spec

[Edit Profile](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan's-Figma?node-id=28%3A8)

### Relevant API Calls

/profile/career - PATCH

Input: { id: STRING, jobTitle: STRING, endDate: DATE, startDate: DATE, organization: STRING }

TBW - Possible Responses:

- Response code number: What that code means

  - Returned information/Error Response: either what would be sent in the data of a valid response or what the error message would be

Note: Any other notes such as if a input or output could only be a set list of results or any other information that is important but not specified above.

### Required Input Validation

endDate/startDate:

- Must be valid dates
- endDate must always be after startDate

## Job Seeker - Delete Career Information

### Why is this functionality needed?

This allows the job seeker to remove careers that they would like to.

### Associated User Types

Only Job Seekers can delete careers this way.

### Default Action Path

Prerequirement: A Job Seeker is signed in and is on their profile page.

1. User clicks the edit button for the Careers section
2. User clicks the edit button for the individual career they want to edit
3. User clicks the delete button.

Postrequirement: The user will not see the deleted career anymore.

### Other Possible Branches

None

### Front End UI Spec

[Edit Profile](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan's-Figma?node-id=28%3A8)

### Relevant API Calls

/profile/career - DELETE

Input: { "id": STRING }

TBW - Possible Responses:

- Response code number: What that code means

  - Returned information/Error Response: either what would be sent in the data of a valid response or what the error message would be

Note: Any other notes such as if a input or output could only be a set list of results or any other information that is important but not specified above.

### Required Input Validation

Career ID:

- Must be a valid id of a career associated with that user.

## Job Seeker - Add Education Information

### Why is this functionality needed?

This allows the job seeker to add education that they have had to the information associated with them.

### Associated User Types

Only Job Seekers can add education this way.

### Default Action Path

Prerequirement: A Job Seeker is signed in and is on their profile page.

1. TBW

Postrequirement: The user will see the information that they have added displayed.

### Other Possible Branches

User inputs invalid information

- TBW

User doesn't input all information

- TBW

### Front End UI Spec

[Edit Profile](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan's-Figma?node-id=28%3A8)

### Relevant API Calls

/profile/education - POST

Input: { "degree": STRING, "gradDate": DATE, "major": STRING, "organization": STRING } (TBD, organization is STRING or ORGANIZATION?)

TBW - Possible Responses:

- Response code number: What that code means

  - Returned information/Error Response: either what would be sent in the data of a valid response or what the error message would be

Note: Any other notes such as if a input or output could only be a set list of results or any other information that is important but not specified above.

### Required Input Validation

TBW - Input label:

- Requirement 1

## Job Seeker - Edit Education Information

### Why is this functionality needed?

This allows the job seeker to edit education that they have had in case it was entered incorrectly or has changed.

### Associated User Types

Only Job Seekers can edit education this way.

### Default Action Path

Prerequirement: A Job Seeker is signed in and is on their profile page.

1. TBW

Postrequirement: The user will see the information that they have added displayed.

### Other Possible Branches

User inputs invalid information

- TBW

User doesn't input all information

- TBW

### Front End UI Spec

[Edit Profile](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan's-Figma?node-id=28%3A8)

### Relevant API Calls

/profile/education - PATCH

Input: { "id": STRING, "education": {"degree": STRING, "gradDate": DATE, "major": STRING, "organization": STRING } } (TBD, organization is STRING or ORGANIZATION?)

TBW - Possible Responses:

- Response code number: What that code means

  - Returned information/Error Response: either what would be sent in the data of a valid response or what the error message would be

Note: Any other notes such as if a input or output could only be a set list of results or any other information that is important but not specified above.

### Required Input Validation

TBW - Input label:

- Requirement 1

## Job Seeker - Delete Education Information

### Why is this functionality needed?

This allows the job seeker to remove education that they would like to.

### Associated User Types

Only Job Seekers can delete education this way.

### Default Action Path

Prerequirement: A Job Seeker is signed in and is on their profile page.

1. TBW

Postrequirement: The user will not see the deleted education anymore.

### Other Possible Branches

User inputs invalid information

- TBW

User doesn't input all information

- TBW

### Front End UI Spec

[Edit Profile](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan's-Figma?node-id=28%3A8)

### Relevant API Calls

WRONG
/profile/education - DELETE

Input: { "id": STRING }

TBW - Possible Responses:

- Response code number: What that code means

  - Returned information/Error Response: either what would be sent in the data of a valid response or what the error message would be

Note: Any other notes such as if a input or output could only be a set list of results or any other information that is important but not specified above.

### Required Input Validation

TBW - Input label:

- Requirement 1

## Job Seeker - Add Skill

### Why is this functionality needed?

So job seekers can add skills that they have to their profile.

### Associated User Types

Only Job Seekers can do this.

### Default Action Path

Prerequirement: The user is logged in and on their profile page

1.

Postrequirement: The user can see that the indicated skill is now added to their profile.

### Other Possible Branches

Branch requirement/reason for it being something different

- What would happen differently

### Front End UI Spec

[Edit Profile](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan's-Figma?node-id=28%3A8)

### Relevant API Calls

/profile/skills - POST

Input: { skills: [{ \_id: STRING }] }

Possible Responses:

- Response code 200: Successfully added skill(s)

  - Returned information: None

- Response code 400: Failed to add skill(s)

  - Returned information: "Failed to add skill: {skill_id}, aborting."

Note: Any other notes such as if a input or output could only be a set list of results or any other information that is important but not specified above.

### Required Input Validation

Skills:

- Must be a valid already existing skill
