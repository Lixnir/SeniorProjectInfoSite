# External Documentation
## Client Side
### [React](https://reactjs.org/docs/getting-started.html)

### [Redux](https://redux.js.org/introduction/getting-started)

### [Material UI](https://material-ui.com/)

### [Cypress](https://docs.cypress.io/guides/overview/why-cypress.html#In-a-nutshell)

## Server Side
### [Node JS](https://nodejs.org/en/docs/)

### [Passport](http://www.passportjs.org/)

### [Express-Validator](https://express-validator.github.io/docs/)

### [JSDocs](https://jsdoc.app/)

### [Mongoose](https://mongoosejs.com/docs/api.html)

### [Jest](https://jestjs.io/docs/en/getting-started) 

## Cloud
### [Azure App Service](https://docs.microsoft.com/en-us/azure/app-service/)

### [Cosmos DB](https://docs.microsoft.com/en-us/azure/cosmos-db/)

# Useful Tools
### [Postman](https://www.postman.com/)

### [Trello](https://trello.com/)

### [Github CI](https://docs.github.com/en/free-pro-team@latest/actions/guides/about-continuous-integration)

### [OpenUP](https://www.eclipse.org/epf/general/OpenUP.pdf)

# Stale Resources
These are resources that exist that were specific to previous teams and may not be useful
moving forward, but are still kept here for reference.

## Previous Teams
### [PHP Site](http://www.fitrskills.com/)

## Fork in The Code Team
### [SE Project Website](http://www.se.rit.edu/~forkinthecode/)

### [Mockups](https://www.figma.com/file/oZvA75m6qDWscrbOqQDbL9/Jordan's-Figma)