# Domain Overview

![Domain-Model.png](./images/domain_model.png)

Within the application, there are three types of users that have been defined.

- **Job Seekers**: The target audience, can list what skills they have, enroll in classes
  to learn new skills, and search for jobs based on skills the currently have.
- **Employers**: Can create job postings that require specific skills as well as recommend
  courses to Job Seekers to learn the skills that they are looking for.
- **Educators**: Can create courses that teach various skills.

**Skill**: The core of the application, this is the feature that should be the most fleshed
out.  Job Seekers can search for skills that lots of jobs in their area are seeking and
subsequently find courses that teach those skills if they do not already have them.

**Class/Course**: These terms are used interchangeably, you will see Course used much more
often.

**Job**: Often referred to as JobPosting.  One employer can create multiple job postings to
to find many job seekers for one or more job positions.

**Organization**: While not denoted in the diagram, an organization is an important concept
that ties job postings and courses together.  An organization is a group that offers job
postings or courses and employers or educators can manage those offerings.

The message is an abstract concept that shows users will need to communicate in various ways
to verify the common skill language.  This concept was not discussed much by the previous
team because we chose to focus on other parts of the application.

#### Domain Extensions
There are several domain concepts that need to be further fleshed out as the application is
developed.

**Field**: A grouping of skills by the type of individuals who have them.  The MVP of this
project is aimed toward a single field, but ultimately a job seeker will want to filter
skills by what field they are relevant in.  A skill will likely be able to be part of
multiple fields.