When dealing with databases that could potentially return thousands of entries, it is important to
consider the efficiency of those executions.  To speed these calls up, only a certain number of
items should be returned at any one time.  This page discusses how pagination should be implemented
to accomplish this.

- **Author**: Alex Wilkes <[adw4236@rit.edu](mailto:adw4236@rit.edu)>

# Pagination
Pagination was something that was always on the back of our mind, but we never had a chance to get
to implementing it.  If you are not aware, pagination is the process of returning "paged" results,
i.e. the first 20 or so before requiring the user to navigate to the next page of results.

This ensures the load time stays satisfying to the user and that there isn't ever too much load on
the database at one time.

There are plenty of ways that pagination could be implemented with mongoose or any other framework,
but [this post](https://stackoverflow.com/questions/5539955/how-to-paginate-with-mongoose-in-node-js)
is at least a starting point.

An alternative to pagination is infinite scrolling that most social media tends towards, but that is
harder to implement and may not be as applicable in this application.