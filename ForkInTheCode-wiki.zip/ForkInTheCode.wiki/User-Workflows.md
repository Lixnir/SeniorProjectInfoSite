An idea that was brought up during a meeting as something that could greatly improve the
UX of the website.  This page discusses how profiles could be more easily populated.

- **Author**: Alex Wilkes <[adw4236@rit.edu](mailto:adw4236@rit.edu)>

# User Workflows
One of the biggest concerns our team had about the application's usability is selecting
the skills that a job seeker already has when joining the website for the first time.
While the current skills search prioritizes the most popular skills to show you, if you
have not yet made an account, you may have to check the same skills you have every
time you search.  While simply creating an account could solve this issue, it is not
the best requirement from a UX perspective.

The suggested alternative is to keep a version of the user profile in localstorage until
the user creates an account in which case the profile would be automatically populated there.
This pseudo profile would remember the skills you have marked as having before you even create
an account. Weather or not this pseudo profile is actually available to be viewed and edited
would be up to the team implementing this feature, but it could certainly help reduce the
redundancy of going through a long list of skills multiple times.

From a technical perspective, as much code should be re-used as possible here to avoid
duplications.  The idea of [common code](https://github.com/FiTRSkills/ForkInTheCode/wiki/Common-Code)
may become very relevant in this implementation.