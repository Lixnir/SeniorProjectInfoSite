export const UPDATE_USER = "@fitr-skills/app/update_user";
export const LOG_OUT = "@fitr-skills/app/log_out";
export const CHANGE_CURRENT_PAGE = "@fitr-skills/app/change_current_page";
export const UPDATE_RESULTS = "@fitr-skills/app/update_results";
export const SET_COURSE_TO_EDIT = "@fitr-skills/app/set_course_to_edit";
export const SET_COURSE_SUCCESS_MESSAGE =
  "@fitr-skills/app/set_course_success_message";
export const SET_JOBPOSTING_SUCCESS_MESSAGE =
  "@fitr-skills/app/set_job_posting_success_message";
export const STORE_SKILLS = "@fitr-skills/app/store_skills";
