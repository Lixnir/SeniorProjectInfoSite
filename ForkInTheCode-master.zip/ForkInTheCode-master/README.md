This project has a [Wiki](https://github.com/Lixnir/ForkInTheCode/wiki)!

For getting started, see [Setting up your Development Environment](https://github.com/Lixnir/ForkInTheCode/wiki/Development-Environment)